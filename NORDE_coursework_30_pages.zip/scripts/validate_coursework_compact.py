from pathlib import Path
from zipfile import ZipFile
import json,re,fitz
from lxml import etree as E
from docx import Document
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'docs/coursework-30';pdf=fitz.open(OUT/'Baev_NORDE_25-30.pdf');doc=Document(OUT/'Baev_NORDE_25-30.docx')
assert 25<=len(pdf)<=30,len(pdf)
sec=doc.sections[0]
mm=lambda x:round(x/36000,1)
assert [mm(sec.left_margin),mm(sec.right_margin),mm(sec.top_margin),mm(sec.bottom_margin)]==[30,15,20,20]
assert doc.styles['Normal'].font.name=='XO Thames'
assert doc.styles['Normal'].font.size.pt==12
assert doc.styles['Normal'].paragraph_format.line_spacing==1.5
structure=json.loads((OUT/'document-structure.json').read_text());mapping=json.loads((OUT/'toc-pages.json').read_text());norm=lambda s:re.sub(r'\s+',' ',s).strip()
for _,heading in structure['headings']:
 assert norm(heading) in norm(pdf[mapping[heading]-1].get_text()),heading
text='\n'.join(p.get_text() for p in pdf)
assert '\uFFFD' not in text
assert not any(c in text for c in ['—','–','−','‑']), 'Long dashes remain in PDF'
assert not any(c in ''.join(p.text for p in doc.paragraphs) for c in ['—','–','−','‑'])
assert 'Анна Миронова' not in text
assert 'Дмитрий' in text
assert all(tool in text for tool in ['Selenium','pytest','Postman','Newman'])
assert 'Supertest' not in text and 'Autocannon' not in text and 'Playwright' not in text
assert '00' not in pdf[1].get_text().split('ВВЕДЕНИЕ')[0]
assert all('Рисунок '+str(n)+'.' in text for n in range(1,len(structure['figures'])+1))
# Check each figure caption and the corresponding image stay on the same page.
for fig in structure['figures']:
 pages=[i+1 for i,p in enumerate(pdf) if f"Рисунок {fig['number']}." in p.get_text()]
 assert len(pages)==1 and pdf[pages[0]-1].get_image_info(),(fig,pages)
fonts=sorted(set(f[3] for page in pdf for f in page.get_fonts()))
assert all('Thames' in f for f in fonts),fonts
with ZipFile(OUT/'Baev_NORDE_25-30.docx') as z:assert 'word/fonts/XOThames-Regular.odttf' in z.namelist()
geometry=[]
for i,page in enumerate(pdf):
 for word in page.get_text('words'):
  if word[0]<42 or word[2]>page.rect.width-24 or word[1]<28 or word[3]>page.rect.height-20:geometry.append({'page':i+1,'word':word[4],'box':word[:4]})
assert not geometry,geometry[:10]
manuals={}
for p in (OUT/'manuals').glob('*.pdf'):
 m=fitz.open(p);assert all(page.get_text().strip() for page in m);assert not any(c in ''.join(page.get_text() for page in m) for c in ['—','–','−','‑']);manuals[p.name]=len(m)
title_data=json.loads((OUT/'title-data.json').read_text())
source=(OUT/'coursework.md').read_text()
body=source.split('# СПИСОК ИСПОЛЬЗОВАННЫХ ИСТОЧНИКОВ')[0]
for n in (1,2):assert f'приложении {n}' in body.lower()
assert 'Вывод по первому разделу:' in body
assert 'https://github.com/alexander2007B/cursovaya' in body.split('# ЗАКЛЮЧЕНИЕ')[1]
assert title_data['group'] in pdf[0].get_text()
assert 'МДК.10.3' in pdf[0].get_text()
assert 'А.П. Баев' in pdf[0].get_text() and 'Д.С. Мартяков' in pdf[0].get_text()
assert pdf[0].get_text().count('2026 г.')==4
cited={int(n) for token in re.findall(r'\[([0-9, ]+)\]',body) for n in re.findall(r'\d+',token)}
assert set(range(1,25))<=cited
for table in doc.tables:
 for row in table.rows:
  for cell in row.cells:
   for paragraph in cell.paragraphs:
    assert paragraph.paragraph_format.line_spacing==1
    assert not paragraph.paragraph_format.first_line_indent
    for run in paragraph.runs:assert run.font.name=='XO Thames' and run.font.size.pt==12
bib=False
for paragraph in doc.paragraphs:
 if paragraph.style.name=='Heading 1':bib=paragraph.text.startswith('СПИСОК ИСПОЛЬЗОВАННЫХ')
 if bib and re.match(r'^\d+\.',paragraph.text):assert not paragraph.paragraph_format.first_line_indent
report={'date':'2026-11-26','pages_total':len(pdf),'pages_before_appendices':mapping['Приложение 1']-1,'figures':len(structure['figures']),'tables':len(structure['tables']),'toc_entries':len(mapping),'font':fonts,'margins_mm':{'left':30,'right':15,'top':20,'bottom':20},'font_size_pt':12,'line_spacing':1.5,'geometry_issues':geometry,'manual_pages':manuals,'current_checks':'2026-11-26: pytest 27 passed (18 domain, 5 API, 4 Selenium); Newman 27 requests, 40 assertions passed; load 4 cases / 12 repeats passed','original_methodology_files':'College Regulation DOCX supplied by user and read directly on 2026-11-26; separate course methodology not available; user confirmed three sections','title_missing_fields':['Нормоконтролёр','Подписи и даты сдачи'],'title_data':title_data,'regulation_conflicts':['6.11 versus Appendix 2: table titles; Appendix 2 retained','6.2 versus Appendix 7: appendix titles in TOC; Appendix 7 retained'],'source_age_status':'See current 24-source HTTP check on 2026-11-26; publication age not established for all living web resources; see source-date-check.json'}
from xml.etree import ElementTree as X
report_dir=ROOT/'docs/reports/selenium-pytest-postman'
for filename,count in [('pytest.xml',27),('load.xml',4)]:
 suites=list(X.parse(report_dir/filename).getroot().iter('testsuite'))
 assert sum(int(s.get('tests',0)) for s in suites)==count
 assert sum(int(s.get(k,0)) for s in suites for k in ['failures','errors'])==0
newman=json.loads((report_dir/'newman-summary.json').read_text())
assert newman['stats']['assertions']['total']==40 and newman['stats']['assertions']['failed']==0
assert newman['stats']['requests']['total']==27
assert json.loads((report_dir/'exit-codes.json').read_text())=={'newman':0,'pytest':0,'load':0}
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
